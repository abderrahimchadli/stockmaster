# StockMaster - Inventory Management for Shopify

StockMaster is a powerful inventory management system designed specifically for Shopify stores. It helps store owners track inventory levels, automate out-of-stock policies, and receive notifications about critical inventory events.

## Features

- **Real-time Inventory Tracking**: Monitor your Shopify inventory in real-time.
- **Automated Rules**: Create and manage rules to automatically hide/unhide products based on inventory levels.
- **Multi-store Support**: Manage inventory across multiple Shopify stores from a single dashboard.
- **Notification System**: Receive alerts via email, Slack, or webhook when inventory levels change or rules are applied.
- **Detailed Analytics**: View historical inventory data and detect trends.
- **User Management**: Add team members with different permission levels.

## Installation

### Prerequisites

- Docker and Docker Compose
- A domain name pointed to your server (for SSL certificates)

### Setup Instructions

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/stockmaster.git
   cd stockmaster
   ```

2. Create your environment file:
   ```
   cp .env.example .env
   ```
   
3. Edit the `.env` file with your specific configurations:
   - Update `SECRET_KEY` with a secure random string
   - Set `ALLOWED_HOSTS` to your domain name
   - Configure database credentials
   - Add your Shopify API credentials
   - Set up email and notification settings

4. Initialize SSL certificates:
   ```
   chmod +x scripts/init-letsencrypt.sh
   ./scripts/init-letsencrypt.sh
   ```

5. Start the application:
   ```
   docker-compose up -d
   ```

6. Create a superuser account:
   ```
   docker-compose exec web python manage.py createsuperuser
   ```

7. Access the application at https://your-domain.com

## Usage

### Adding a Shopify Store

1. Log in to the StockMaster dashboard
2. Navigate to Stores → Add New Store
3. Follow the OAuth flow to connect your Shopify store
4. Once connected, StockMaster will begin syncing your inventory

### Creating Inventory Rules

1. Go to Rules → Add New Rule
2. Select the store and products to apply the rule to
3. Configure the conditions (e.g., hide when inventory < 3)
4. Set up any notifications for when the rule is applied
5. Save the rule and activate it

### Setting Up Notifications

1. Navigate to Settings → Notifications
2. Configure your preferred notification channels:
   - Email: Set recipient addresses
   - Slack: Configure webhook URL
   - Custom webhook: Set endpoint URL and payload format
3. Choose which events trigger notifications

## Development

### Local Development Setup

1. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up environment variables for development:
   ```
   cp .env.example .env.dev
   ```

4. Run migrations:
   ```
   python manage.py migrate
   ```

5. Start the development server:
   ```
   python manage.py runserver
   ```

### Running Tests

```
python manage.py test
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, please open an issue on our GitHub repository or contact support@stockmaster.com.

## Acknowledgements

- Built with Django and Celery
- Shopify API integration
- Uses PostgreSQL for data storage
- Redis for caching and Celery broker 